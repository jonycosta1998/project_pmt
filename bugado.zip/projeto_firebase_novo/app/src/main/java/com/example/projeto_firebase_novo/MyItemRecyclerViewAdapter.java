package com.example.projeto_firebase_novo;

import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.projeto_firebase_novo.ItemFragment.OnListFragmentInteractionListener;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link Car} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MyItemRecyclerViewAdapter extends RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder> {

    private final List<Car> mValues;
    private final OnListFragmentInteractionListener mListener;

    public MyItemRecyclerViewAdapter(List<Car> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        Car task = mValues.get(position);
        holder.mItem = task;

        holder.mMakerView.setText(task.carMaker);
        holder.mModelView.setText(task.carModel);
        holder.mYearBuildView.setText(task.carBuildYear);
        holder.mEngineView.setText(task.carEngine);

    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView mMakerView;
        public final TextView mModelView;
        public final TextView mYearBuildView;
        public final TextView mEngineView;
        public Car mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mMakerView = (TextView) view.findViewById(R.id.maker);
            mModelView = (TextView) view.findViewById(R.id.model);
            mYearBuildView = (TextView) view.findViewById(R.id.buildYear);
            mEngineView = (TextView) view.findViewById(R.id.engine);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mMakerView.getText() + "'";
        }
    }
}
